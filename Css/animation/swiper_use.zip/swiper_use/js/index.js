(function(){

  setTimeout(() => {

    document.querySelector('.flag').className='flag flag-anima'
    document.querySelector('.flag-word').className='flag-word flag-word-anima'
    document.querySelector('.desc').className='desc desc-anima'
    document.querySelector('.title').className='title title-anima'
    document.querySelector('.people-fake').className='people-fake people-fake-anima'
    document.querySelector('.peoples').className='peoples peoples-anima'
 
  })

})()